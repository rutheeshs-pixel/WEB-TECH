document.addEventListener('DOMContentLoaded', () => {
  const toggleBtn = document.getElementById('toggle-sprint-btn');
  const sprintPanel = document.getElementById('sprint-details-panel');
  const notifyBtn = document.getElementById('trigger-alert-btn');
  const toastBanner = document.getElementById('sprint-toast');

  if (toggleBtn && sprintPanel) {
    toggleBtn.addEventListener('click', () => {
      sprintPanel.classList.toggle('open');
      const isOpen = sprintPanel.classList.contains('open');
      toggleBtn.textContent = isOpen ? 'Hide Release Checklist' : 'View Release Checklist';
    });
  }

  if (notifyBtn && toastBanner) {
    notifyBtn.addEventListener('click', () => {
      toastBanner.classList.add('show');
      setTimeout(() => {
        toastBanner.classList.remove('show');
      }, 3500);
    });
  }
});

// Practicum 10: Dynamic DOM Manipulation for Team Assignments
document.addEventListener('DOMContentLoaded', () => {
  const addMemberBtn = document.getElementById('dom-add-member-btn');
  const memberNameInput = document.getElementById('dom-member-name');
  const memberRoleInput = document.getElementById('dom-member-role');
  const teamList = document.getElementById('dynamic-team-list');

  function bindRemoveButtons() {
    const removeBtns = teamList.querySelectorAll('.remove-member-btn');
    removeBtns.forEach((btn) => {
      btn.onclick = function () {
        this.parentElement.remove();
      };
    });
  }

  if (teamList) {
    bindRemoveButtons();
  }

  if (addMemberBtn && memberNameInput && memberRoleInput && teamList) {
    addMemberBtn.addEventListener('click', () => {
      const name = memberNameInput.value.trim();
      const role = memberRoleInput.value.trim();
      if (!name || !role) return;

      const li = document.createElement('li');
      const infoSpan = document.createElement('span');
      infoSpan.innerHTML = `<strong>${name}</strong> — ${role}`;

      const removeBtn = document.createElement('button');
      removeBtn.type = 'button';
      removeBtn.textContent = 'Remove';
      removeBtn.className = 'btn-small remove-member-btn';
      removeBtn.setAttribute('aria-label', `Remove ${name}`);
      removeBtn.addEventListener('click', () => li.remove());

      li.appendChild(infoSpan);
      li.appendChild(removeBtn);
      teamList.appendChild(li);

      memberNameInput.value = '';
      memberRoleInput.value = '';
    });
  }
});

// Practicum 11: HTML5 Constraint Validation API
document.addEventListener('DOMContentLoaded', () => {
  const projectForm = document.getElementById('validated-project-form');
  const codeInput = document.getElementById('proj-code');
  const feedbackBox = document.getElementById('form-validation-msg');

  if (codeInput) {
    codeInput.addEventListener('input', () => {
      const pattern = /^PRJ-[0-9]{3}$/;
      if (!pattern.test(codeInput.value)) {
        codeInput.setCustomValidity('Project Code must match format PRJ-105 (PRJ- followed by 3 digits).');
      } else {
        codeInput.setCustomValidity('');
      }
    });
  }

  if (projectForm && feedbackBox) {
    projectForm.addEventListener('submit', (e) => {
      e.preventDefault();
      if (!projectForm.checkValidity()) {
        projectForm.reportValidity();
        feedbackBox.textContent = 'Validation failed: Please correct the highlighted fields.';
        feedbackBox.className = 'form-feedback error';
        return;
      }

      const nameVal = document.getElementById('proj-name').value.trim();
      const codeVal = codeInput ? codeInput.value.trim() : 'PRJ-NEW';
      feedbackBox.textContent = `Success: Project "${nameVal}" (${codeVal}) passed validation and was queued for sprint intake.`;
      feedbackBox.className = 'form-feedback success';
      projectForm.reset();
    });
  }
});
