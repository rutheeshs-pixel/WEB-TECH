document.addEventListener('DOMContentLoaded', () => {
  const toggleBtn = document.getElementById('toggle-sprint-btn');
  const sprintPanel = document.getElementById('sprint-details-panel');
  const notifyBtn = document.getElementById('trigger-alert-btn');
  const toastBanner = document.getElementById('sprint-toast');

  if (toggleBtn && sprintPanel) {
    toggleBtn.addEventListener('click', () => {
      sprintPanel.classList.toggle('open');
      const isOpen = sprintPanel.classList.contains('open');
      toggleBtn.textContent = isOpen ? 'Hide Release Checklist' : 'View Release Checklist';
    });
  }

  if (notifyBtn && toastBanner) {
    notifyBtn.addEventListener('click', () => {
      toastBanner.classList.add('show');
      setTimeout(() => {
        toastBanner.classList.remove('show');
      }, 3500);
    });
  }
});

// Practicum 10: Dynamic DOM Manipulation for Team Assignments
document.addEventListener('DOMContentLoaded', () => {
  const addMemberBtn = document.getElementById('dom-add-member-btn');
  const memberNameInput = document.getElementById('dom-member-name');
  const memberRoleInput = document.getElementById('dom-member-role');
  const teamList = document.getElementById('dynamic-team-list');

  function bindRemoveButtons() {
    const removeBtns = teamList.querySelectorAll('.remove-member-btn');
    removeBtns.forEach((btn) => {
      btn.onclick = function () {
        this.parentElement.remove();
      };
    });
  }

  if (teamList) {
    bindRemoveButtons();
  }

  if (addMemberBtn && memberNameInput && memberRoleInput && teamList) {
    addMemberBtn.addEventListener('click', () => {
      const name = memberNameInput.value.trim();
      const role = memberRoleInput.value.trim();
      if (!name || !role) return;

      const li = document.createElement('li');
      const infoSpan = document.createElement('span');
      infoSpan.innerHTML = `<strong>${name}</strong> — ${role}`;

      const removeBtn = document.createElement('button');
      removeBtn.type = 'button';
      removeBtn.textContent = 'Remove';
      removeBtn.className = 'btn-small remove-member-btn';
      removeBtn.setAttribute('aria-label', `Remove ${name}`);
      removeBtn.addEventListener('click', () => li.remove());

      li.appendChild(infoSpan);
      li.appendChild(removeBtn);
      teamList.appendChild(li);

      memberNameInput.value = '';
      memberRoleInput.value = '';
    });
  }
});

// Practicum 11: HTML5 Constraint Validation API
document.addEventListener('DOMContentLoaded', () => {
  const projectForm = document.getElementById('validated-project-form');
  const codeInput = document.getElementById('proj-code');
  const feedbackBox = document.getElementById('form-validation-msg');

  if (codeInput) {
    codeInput.addEventListener('input', () => {
      const pattern = /^PRJ-[0-9]{3}$/;
      if (!pattern.test(codeInput.value)) {
        codeInput.setCustomValidity('Project Code must match format PRJ-105 (PRJ- followed by 3 digits).');
      } else {
        codeInput.setCustomValidity('');
      }
    });
  }

  if (projectForm && feedbackBox) {
    projectForm.addEventListener('submit', (e) => {
      e.preventDefault();
      if (!projectForm.checkValidity()) {
        projectForm.reportValidity();
        feedbackBox.textContent = 'Validation failed: Please correct the highlighted fields.';
        feedbackBox.className = 'form-feedback error';
        return;
      }

      const nameVal = document.getElementById('proj-name').value.trim();
      const codeVal = codeInput ? codeInput.value.trim() : 'PRJ-NEW';
      feedbackBox.textContent = `Success: Project "${nameVal}" (${codeVal}) passed validation and was queued for sprint intake.`;
      feedbackBox.className = 'form-feedback success';
      projectForm.reset();
    });
  }
});

// Practicum 12: Async/Await Fetch API Endpoint Integration
document.addEventListener('DOMContentLoaded', () => {
  const fetchBtn = document.getElementById('fetch-api-projects-btn');
  const apiStatus = document.getElementById('api-fetch-status');
  const apiTableBody = document.getElementById('api-projects-tbody');

  async function loadRemoteProjects() {
    if (!apiTableBody || !apiStatus) return;
    apiStatus.textContent = 'Loading remote sprint repositories from endpoint...';
    apiTableBody.innerHTML = '';

    try {
      const response = await fetch('https://jsonplaceholder.typicode.com/users?_limit=4');
      if (!response.ok) {
        throw new Error(`HTTP Error ${response.status}`);
      }
      const data = await response.json();

      const milestones = ['API Gateway v2', 'Zero-Trust Auth', 'Telemetry Stream', 'Mobile SDK RC1'];
      const statuses = ['In Progress', 'Completed', 'At Risk', 'In Progress'];

      data.forEach((user, idx) => {
        const tr = document.createElement('tr');

        const tdId = document.createElement('td');
        tdId.textContent = `EXT-20${user.id}`;

        const tdProj = document.createElement('td');
        tdProj.textContent = `${user.company.name} Platform`;

        const tdLead = document.createElement('td');
        tdLead.textContent = user.name;

        const tdMile = document.createElement('td');
        tdMile.textContent = milestones[idx % milestones.length];

        const tdStatus = document.createElement('td');
        tdStatus.textContent = statuses[idx % statuses.length];

        tr.appendChild(tdId);
        tr.appendChild(tdProj);
        tr.appendChild(tdLead);
        tr.appendChild(tdMile);
        tr.appendChild(tdStatus);
        apiTableBody.appendChild(tr);
      });

      apiStatus.textContent = `Synced ${data.length} external client deliverables successfully.`;
    } catch (err) {
      apiStatus.textContent = `Endpoint Error: ${err.message}. Showing offline fallback notice.`;
    } finally {
      console.log('Endpoint sync cycle completed.');
    }
  }

  if (fetchBtn) {
    fetchBtn.addEventListener('click', loadRemoteProjects);
    loadRemoteProjects();
  }
});
