document.addEventListener('DOMContentLoaded', () => {
  const toggleBtn = document.getElementById('toggle-sprint-btn');
  const sprintPanel = document.getElementById('sprint-details-panel');
  const notifyBtn = document.getElementById('trigger-alert-btn');
  const toastBanner = document.getElementById('sprint-toast');

  if (toggleBtn && sprintPanel) {
    toggleBtn.addEventListener('click', () => {
      sprintPanel.classList.toggle('open');
      const isOpen = sprintPanel.classList.contains('open');
      toggleBtn.textContent = isOpen ? 'Hide Release Checklist' : 'View Release Checklist';
    });
  }

  if (notifyBtn && toastBanner) {
    notifyBtn.addEventListener('click', () => {
      toastBanner.classList.add('show');
      setTimeout(() => {
        toastBanner.classList.remove('show');
      }, 3500);
    });
  }
});
