document.addEventListener('DOMContentLoaded', () => {
  const toggleBtn = document.getElementById('toggle-sprint-btn');
  const sprintPanel = document.getElementById('sprint-details-panel');
  const notifyBtn = document.getElementById('trigger-alert-btn');
  const toastBanner = document.getElementById('sprint-toast');

  if (toggleBtn && sprintPanel) {
    toggleBtn.addEventListener('click', () => {
      sprintPanel.classList.toggle('open');
      const isOpen = sprintPanel.classList.contains('open');
      toggleBtn.textContent = isOpen ? 'Hide Release Checklist' : 'View Release Checklist';
    });
  }

  if (notifyBtn && toastBanner) {
    notifyBtn.addEventListener('click', () => {
      toastBanner.classList.add('show');
      setTimeout(() => {
        toastBanner.classList.remove('show');
      }, 3500);
    });
  }
});

// Practicum 10: Dynamic DOM Manipulation for Team Assignments
document.addEventListener('DOMContentLoaded', () => {
  const addMemberBtn = document.getElementById('dom-add-member-btn');
  const memberNameInput = document.getElementById('dom-member-name');
  const memberRoleInput = document.getElementById('dom-member-role');
  const teamList = document.getElementById('dynamic-team-list');

  function bindRemoveButtons() {
    const removeBtns = teamList.querySelectorAll('.remove-member-btn');
    removeBtns.forEach((btn) => {
      btn.onclick = function () {
        this.parentElement.remove();
      };
    });
  }

  if (teamList) {
    bindRemoveButtons();
  }

  if (addMemberBtn && memberNameInput && memberRoleInput && teamList) {
    addMemberBtn.addEventListener('click', () => {
      const name = memberNameInput.value.trim();
      const role = memberRoleInput.value.trim();
      if (!name || !role) return;

      const li = document.createElement('li');
      const infoSpan = document.createElement('span');
      infoSpan.innerHTML = `<strong>${name}</strong> — ${role}`;

      const removeBtn = document.createElement('button');
      removeBtn.type = 'button';
      removeBtn.textContent = 'Remove';
      removeBtn.className = 'btn-small remove-member-btn';
      removeBtn.setAttribute('aria-label', `Remove ${name}`);
      removeBtn.addEventListener('click', () => li.remove());

      li.appendChild(infoSpan);
      li.appendChild(removeBtn);
      teamList.appendChild(li);

      memberNameInput.value = '';
      memberRoleInput.value = '';
    });
  }
});
